﻿# Import the module into the PowerShell session
Import-Module AzureRM

# Connect to Azure with an interactive dialogue for sign-in
Connect-AzureRmAccount

# Setup all parametars
$resourceGroupName = "E2EMigratedMachine_erwinDMM"
$myVHD = "C:\machines\erwinDMM.VHD"
$virtualNetworkName = "E2ENetwork"
$locationName = "eastus"
$destinationVhd ="https://e2enetworks.blob.core.windows.net/vhd/erwinDMM.VHD"
$VMname="erwinDMM"
$NICName="erwinDMM-NIC1"
$PIPName="erwinDMM-PIP1"
$OSDisk="erwinDMM-Disk"
Get-AzureRmVMSize $locationName | Out-GridView
$VMSize="Standard_D8s_v4"



#Upload
Add-AzureRmVhd -ResourceGroupName $resourceGroupName -Destination $destinationVhd -LocalFilePath $myVHD

# Configure Azure Network
$virtualNetwork = Get-AzureRmVirtualNetwork -ResourceGroupName $resourceGroupName -Name $virtualNetworkName
$publicIp = New-AzureRmPublicIpAddress -Name $PIPName -ResourceGroupName $ResourceGroupName -Location $locationName -AllocationMethod Dynamic
$networkInterface = New-AzureRmNetworkInterface -ResourceGroupName $resourceGroupName -Name $NICName -Location $locationName -SubnetId $virtualNetwork.Subnets[0].Id -PublicIpAddressId $publicIp.Id

# Configure VM
$vmConfig = New-AzureRmVMConfig -VMName $VMname -VMSize $VMSize
$vmConfig = Set-AzureRmVMOSDisk -VM $vmConfig -Name $OSDisk -VhdUri $destinationVhd -CreateOption Attach -Windows
$vmConfig = Add-AzureRmVMNetworkInterface -VM $vmConfig -Id $networkInterface.Id

#Create VM
$vm = New-AzureRmVM -VM $vmConfig -Location $locationName -ResourceGroupName $resourceGroupName